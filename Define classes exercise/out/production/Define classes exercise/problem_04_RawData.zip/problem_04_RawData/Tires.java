package problem_04_RawData;

public class Tires {
    double pressure;
    int year;

    public Tires(double pressure, int year) {
        this.pressure = pressure;
        this.year = year;
    }

    public double getPressure() {
        return pressure;
    }
}
