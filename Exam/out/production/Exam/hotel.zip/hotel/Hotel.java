package hotel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Hotel {

    private String name;
    private int capacity;
    private Map<String, Person> guests;

    public Hotel(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.guests = new LinkedHashMap<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Map<String, Person> getGuests() {
        return guests;
    }

    public void setGuests(Map<String, Person> guests) {
        this.guests = guests;
    }

    public void add(Person person) {
        if (this.capacity > 0) {
            this.guests.putIfAbsent(person.getName(), person);
        }
    }

    public boolean remove(String name) {
        if (this.guests.containsKey(name)) {
            this.guests.remove(name);
            return true;
        }
        return false;
    }

    public Person getPerson(String name, String hometown) {
        if (guests.containsKey(name)) {
            if (this.guests.get(name).getHometown().equals(hometown)) {
                return guests.get(name);
            }
        }
        return null;
    }

    public int getCount() {
        return guests.size();
    }

    public String getStatistics() {
        StringBuilder hotelGuestsInfo = new StringBuilder();
        hotelGuestsInfo.append(
        String.format("The people in the hotel %s are", this.getName()))
                .append(System.lineSeparator());

        for (Person person : guests.values()) {
            hotelGuestsInfo.append(person).append(System.lineSeparator());
        }

        return hotelGuestsInfo.toString().trim();
    }
}
